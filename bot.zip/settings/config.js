global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6283805512180'] 